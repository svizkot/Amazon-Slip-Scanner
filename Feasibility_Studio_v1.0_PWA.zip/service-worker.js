const CACHE='feasibility-studio-v1';
const URLS=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',ev=>{ev.waitUntil(caches.open(CACHE).then(c=>c.addAll(URLS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',ev=>{ev.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',ev=>{if(ev.request.method==='GET'&&new URL(ev.request.url).origin===self.location.origin){ev.respondWith(caches.match(ev.request).then(r=>r||fetch(ev.request)))}});
